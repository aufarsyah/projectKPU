1.4.0 / 2019-05-03
===================

* Fixed #33 https://github.com/lemonce/svg-captcha/pull/33

1.3.11 / 2017-08-23
===================

* Fix typescript definition

1.3.9 / 2017-07-23
===================

* Fix charSet options

1.3.8 / 2017-07-20
===================

* Bump `opentype.js@0.7.3`

1.3.7 / 2017-06-11
===================

* Bump `opentype.js@0.7.2`

1.3.6 / 2017-06-03
===================

* Improve security by randomize svg path command

1.3.5 / 2017-05-08
===================

* Bump `opentype.js@0.7.1`
* Fixed some code style inconsistence