**Do you want to request a *feature* or report a *bug*?**

**If this is a feature request, what is motivation for changing the behavior?**

**If it is a bug, which version of svg-captcha are you using?**

**What is the current behavior?**

**What is the expected behavior?**

**Step to reproduce the bug or other relevant information**
